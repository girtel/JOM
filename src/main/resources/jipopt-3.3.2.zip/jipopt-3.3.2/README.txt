= Ipopt Java Interface =

This is the Java Native Interface (JNI) for the Ipopt optimization solver.

Author: Rafael de Pelegrini Soares

http://www.vrtech.com.br - VRTech Industrial Technologies

For more details check the online documentation available at
https://projects.coin-or.org/Ipopt/wiki/JavaInterface

== License ==

 - JIpopt is available under the Commom Plublic License
 - [https://projects.coin-or.org/Ipopt Ipopt] is available under the Commom Plublic License
 - [http://graal.ens-lyon.fr/MUMPS/ MUMPS] is public domain
 
